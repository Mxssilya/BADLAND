
#include <allegro.h>
#include "niveau1.h"


//fonction pour initaliser l'audio
void initialiser_audio() {
    //installer le système audio d'Allegro
    if (install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL) != 0) {
        allegro_message("Erreur lors de l'initialisation du son : %s", allegro_error);
        return;
    }

    //régler le volume
    set_volume(255, 255);

    //charger les musiques (en MIDI)
    musique_menu = load_midi("menu.mid");
    musique_niveau1 = load_midi("niveau1.mid");

    //charger les effets sonores (en WAV)
    son_debut_niveau = load_sample("gamestart.wav");
    son_game_over = load_sample("gameover.wav");
    son_victoire = load_sample("levelcomplete.wav");
}

//fonction pour nettoyer l'audio
void nettoyer_audio() {
    //arrêter la musique
    stop_midi();

    //libérer les ressources audio
    if (musique_menu) destroy_midi(musique_menu);
    if (musique_niveau1) destroy_midi(musique_niveau1);
    if (son_debut_niveau) destroy_sample(son_debut_niveau);
    if (son_game_over) destroy_sample(son_game_over);
    if (son_victoire) destroy_sample(son_victoire);
}

//fonction pour jouer une musique en boucle
void jouer_musique(MIDI *musique, int *en_cours) {
    if (musique && musique_activee && !(*en_cours)) {
        // Arrêter les musiques en cours
        if (midi_pos >= 0) {
            stop_midi();
        }

        // Réinitialiser les indicateurs
        musique_menu_en_cours = 0;
        musique_niveau_en_cours = 0;

        // Jouer la nouvelle musique
        play_midi(musique, 1);  // 1 = jouer en boucle
        *en_cours = 1;
    }
}

//fonction pour jouer un effet sonore
void jouer_son(SAMPLE *son) {
    if (son) {
        play_sample(son, 200, 128, 1000, 0); // Volume, pan, fréquence, boucle (0 = non)
    }
}

//fonction pour basculer
void basculer_musique() {
    musique_activee = !musique_activee;

    if (musique_activee) {
        // Reprendre la musique qui était en cours
        if (musique_menu_en_cours) {
            play_midi(musique_menu, 1);
        } else if (musique_niveau_en_cours) {
            play_midi(musique_niveau1, 1);
        }
    } else {
        // Mettre en pause la musique
        stop_midi();
    }
}

