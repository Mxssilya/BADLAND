
#include "joueur.h"
#include <allegro.h>
#include <stdio.h>

#include "menu.h"
#include "niveau1.h"

void saisir_pseudo(char *pseudo) {
    int pos = strlen(pseudo);
    int touche;
    int clignotement = 0;
    int temps_precedent = 0;

    //on définit le cadre de saisie
    int cadre_x = LARGEUR_ECRAN / 2 - 150;
    int cadre_y = 250;
    int cadre_largeur = 300;
    int cadre_hauteur = 40;

    show_mouse(NULL);

    while (1) {
        if (keypressed()) {
            touche = readkey();

            //on récupère le code ASCII de la touche
            char caractere = touche & 0xff;

            //touche Entrée pour valider
            if (caractere == 13) {
                break;
            }
            //touche Échap pour annuler
            else if (caractere == 27) {
                pseudo[0] = '\0';
                break;
            }
            //touche Retour arrière pour effacer
            else if (caractere == 8 && pos > 0) {
                pos--;
                pseudo[pos] = '\0';
            }
            //ajoute le caractère au pseudo si c'est une lettre, un chiffre ou un underscore
            else if ((caractere >= 'a' && caractere <= 'z') ||
                     (caractere >= 'A' && caractere <= 'Z') ||
                     (caractere >= '0' && caractere <= '9') ||
                     caractere == '_') {
                if (pos < MAX_PSEUDO - 1) {
                    pseudo[pos] = caractere;
                    pos++;
                    pseudo[pos] = '\0';
                }
            }
        }

        //mise à jour du clignotement du curseur toutes les 500ms
        if (clock() - temps_precedent > 500) {
            clignotement = !clignotement;
            temps_precedent = clock();
        }

        //affichage du fond et du pseudo en cours de saisie
        dessiner_fond();
        textout_centre_ex(buffer, police, "Entrez votre pseudo :", LARGEUR_ECRAN / 2, 200, makecol(255, 255, 255), -1);

        //cadre pour la saisie
        rectfill(buffer, cadre_x, cadre_y, cadre_x + cadre_largeur, cadre_y + cadre_hauteur, makecol(10, 10, 15));
        rect(buffer, cadre_x, cadre_y, cadre_x + cadre_largeur, cadre_y + cadre_hauteur, makecol(200, 200, 200));

        //affichage du pseudo
        textout_ex(buffer, police, pseudo, cadre_x + 10, cadre_y + 10, makecol(255, 255, 255), -1);

        //affichage du curseur clignotant
        if (clignotement) {
            int curseur_x = cadre_x + 10 + text_length(police, pseudo);
            vline(buffer, curseur_x, cadre_y + 10, cadre_y + 30, makecol(255, 255, 255));
        }

        textout_centre_ex(buffer, police, "Appuyez sur Entree pour valider", LARGEUR_ECRAN / 2, 320, makecol(200, 200, 200), -1);

        //affichage du buffer à l'écran
        blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);

        //petite pause
        rest(10);
    }

    show_mouse(screen);
}

int charger_joueurs(Joueur *joueurs) {
    FILE *fichier = fopen("joueurs.dat", "rb");
    int count = 0;

    if (fichier) {
        count = fread(joueurs, sizeof(Joueur), MAX_JOUEURS, fichier);
        fclose(fichier);
    }

    return count;
}

void sauvegarder_joueurs(Joueur *joueurs, int nb_joueurs) {
    FILE *fichier = fopen("joueurs.dat", "wb");

    if (fichier) {
        fwrite(joueurs, sizeof(Joueur), nb_joueurs, fichier);
        fclose(fichier);
    }
}

int trouver_joueur(Joueur *joueurs, int nb_joueurs, char *pseudo) {
    int i;

    for (i = 0; i < nb_joueurs; i++) {
        if (strcmp(joueurs[i].pseudo, pseudo) == 0) {
            return i;
        }
    }

    return -1;  //le joueur n'est pas trouvé
}

void ajouter_joueur(Joueur *joueurs, int *nb_joueurs, char *pseudo) {
    if (*nb_joueurs < MAX_JOUEURS) {
        strcpy(joueurs[*nb_joueurs].pseudo, pseudo);
        joueurs[*nb_joueurs].niveau_debloque = 1;  // Commence au niveau 1
        (*nb_joueurs)++;
    }
}


