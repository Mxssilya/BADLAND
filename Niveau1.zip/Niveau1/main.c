#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "niveau1.h"
#include "audio.h"
#include "joueur.h"
#include "menu.h"

#include "niveau1.h"

// Définition des variables globales
BITMAP *buffer = NULL;
BITMAP *fond_menu = NULL;
FONT *police = NULL;
Joueur joueurs[MAX_JOUEURS];
int nb_joueurs = 0;
char pseudo_actuel[MAX_PSEUDO] = "";
int joueur_actuel = -1;
int etape_menu = 0;

SAMPLE *son_debut_niveau = NULL;
SAMPLE *son_game_over = NULL;
SAMPLE *son_victoire = NULL;
MIDI *musique_menu = NULL;
MIDI *musique_niveau1 = NULL;
int musique_activee = 1;
int musique_menu_en_cours = 0;
int musique_niveau_en_cours = 0;

int selection_menu1 = 0;
int selection_menu2 = 0;
int selection_quitter = 1;

void initialiser_audio();

void initialiser_allegro() {
    allegro_init();
    install_keyboard();
    install_mouse();
    install_timer();

    // Initialiser l'audio
    initialiser_audio();

    set_color_depth(32);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, LARGEUR_ECRAN, HAUTEUR_ECRAN, 0, 0);

    buffer = create_bitmap(LARGEUR_ECRAN, HAUTEUR_ECRAN);
    police = font;  // Utilisation de la police par défaut d'Allegro

    fond_menu = load_bitmap("menu-principal.bmp", NULL);
    if(!fond_menu) {
        fond_menu = create_bitmap(LARGEUR_ECRAN, HAUTEUR_ECRAN);
        clear_to_color(fond_menu, makecol(20, 20, 30));
    }

    set_window_title("BadLand - Projet Allegro ING1 2025");
}

void nettoyer_allegro() {
    // Nettoyer l'audio
    nettoyer_audio();

    if (buffer) {
        destroy_bitmap(buffer);
    }

    if(fond_menu) {
        destroy_bitmap(fond_menu);
    }
    allegro_exit();
}

int main() {
   initialiser_allegro();

   // Lancer la musique du menu
   jouer_musique(musique_menu, &musique_menu_en_cours);

   // On charge les joueurs depuis le fichier
   nb_joueurs = charger_joueurs(joueurs);

   int sortie = 0;
   int touche_m_pressee = 0;  // Pour gérer la touche M (musique)

   // Variables pour la navigation au clavier dans les menus
   int touche_gauche_pressee = 0;
   int touche_droite_pressee = 0;
   int touche_haut_pressee = 0;
   int touche_bas_pressee = 0;
   int touche_entree_pressee = 0;

   while (!sortie) {
       // Gestion de la touche M pour activer/désactiver la musique
       if (key[KEY_M] && !touche_m_pressee) {
           touche_m_pressee = 1;
           basculer_musique();
       }
       else if (!key[KEY_M]) {
           touche_m_pressee = 0;
       }

       // Vérification des entrées clavier
       if (key[KEY_ESC]) {
           if (etape_menu == 2) { // Si on est dans le menu principal
               etape_menu = 4;    // Aller à la confirmation de sortie
               selection_quitter = 0; // Sélectionner "Non" par défaut pour éviter les sorties accidentelles

               // Vider le buffer clavier pour éviter les détections multiples
               clear_keybuf();

               // Petite pause pour éviter les déclenchements accidentels
               rest(200);
           } else if (etape_menu == 3 || etape_menu == 4) { // Si on est dans l'aide ou la confirmation
               etape_menu = 2;    // Retour au menu principal
               clear_keybuf();    // Vider le buffer clavier
               rest(200);         // Petite pause
           } else {
               sortie = 1;        // Sortir de la boucle principale
           }

           // Pour éviter de détecter plusieurs appuis
           while (key[KEY_ESC]) {
               rest(10);
           }
       }

       //gestion des clics souris
       int clic = mouse_b & 1;

       //dessiner le fond
       dessiner_fond();

       //gestion des différentes étapes du menu
       switch (etape_menu) {
           case 0:  //saisie du pseudo
               if (pseudo_actuel[0] == '\0') {
                   saisir_pseudo(pseudo_actuel);

                   if (pseudo_actuel[0] != '\0') {
                       // Chercher si le joueur existe déjà
                       joueur_actuel = trouver_joueur(joueurs, nb_joueurs, pseudo_actuel);

                       if (joueur_actuel == -1) {
                           // Nouveau joueur - ajouter directement et passer au menu principal
                           ajouter_joueur(joueurs, &nb_joueurs, pseudo_actuel);
                           joueur_actuel = nb_joueurs - 1;
                           sauvegarder_joueurs(joueurs, nb_joueurs);

                           // Pour un nouveau joueur, on passe directement au menu principal
                           etape_menu = 2;
                           selection_menu2 = 0; // Reset la sélection du menu principal
                           clear_keybuf();
                           rest(200);
                       } else {
                           // Joueur existant - proposer de continuer ou recommencer
                           etape_menu = 1;
                           selection_menu1 = 0;
                           clear_keybuf();
                           rest(200);
                       }
                   }
               }
               break;

           case 1:  //choix nouvelle partie ou reprendre
               textout_centre_ex(buffer, police, "Bienvenue, ", LARGEUR_ECRAN / 2 - 80, 150, makecol(255, 255, 255), -1);
               textout_ex(buffer, police, pseudo_actuel, LARGEUR_ECRAN / 2 + 20, 150, makecol(255, 255, 100), -1);

               //bouton nouvelle partie
               int btn_nouvelle_x = LARGEUR_ECRAN / 2 - 200;
               int btn_nouvelle_y = 250;
               int btn_largeur = 180;
               int btn_hauteur = 50;

               // Gestion des flèches gauche/droite
               if (key[KEY_LEFT] && !touche_gauche_pressee) {
                   touche_gauche_pressee = 1;
                   selection_menu1 = 0; // Nouvelle partie (gauche)
               } else if (!key[KEY_LEFT]) {
                   touche_gauche_pressee = 0;
               }

               if (key[KEY_RIGHT] && !touche_droite_pressee) {
                   touche_droite_pressee = 1;
                   selection_menu1 = 1; // Reprendre partie (droite)
               } else if (!key[KEY_RIGHT]) {
                   touche_droite_pressee = 0;
               }

               // Gestion de la touche Entrée
               if (key[KEY_ENTER] && !touche_entree_pressee) {
                   touche_entree_pressee = 1;

                   if (selection_menu1 == 0) {
                       // Nouvelle partie, commence au niveau 1
                       joueurs[joueur_actuel].niveau_debloque = 1;
                       sauvegarder_joueurs(joueurs, nb_joueurs);
                       etape_menu = 2;
                       selection_menu2 = 0; // Réinitialiser la sélection du menu principal
                   } else {
                       // Reprendre la partie au niveau débloqué
                       etape_menu = 2;
                       selection_menu2 = 0; // Réinitialiser la sélection du menu principal
                   }
               } else if (!key[KEY_ENTER]) {
                   touche_entree_pressee = 0;
               }

               // Déterminer les couleurs des boutons en fonction de la sélection
               int couleur_nouvelle = (selection_menu1 == 0) ?
                                      makecol(100, 150, 100) : makecol(50, 100, 50);

               dessiner_bouton(btn_nouvelle_x, btn_nouvelle_y, btn_largeur, btn_hauteur,
                              "Nouvelle partie", couleur_nouvelle, makecol(255, 255, 255));

               // Indiquer la sélection avec un rectangle
               if (selection_menu1 == 0) {
                   rect(buffer, btn_nouvelle_x - 2, btn_nouvelle_y - 2,
                        btn_nouvelle_x + btn_largeur + 2, btn_nouvelle_y + btn_hauteur + 2,
                        makecol(255, 255, 0));
               }

               //bouton reprendre partie
               int btn_reprendre_x = LARGEUR_ECRAN / 2 + 20;
               int btn_reprendre_y = 250;

               int couleur_reprendre = (selection_menu1 == 1) ?
                                       makecol(150, 100, 100) : makecol(100, 50, 50);

               dessiner_bouton(btn_reprendre_x, btn_reprendre_y, btn_largeur, btn_hauteur,
                              "Reprendre partie", couleur_reprendre, makecol(255, 255, 255));

               // Indiquer la sélection avec un rectangle
               if (selection_menu1 == 1) {
                   rect(buffer, btn_reprendre_x - 2, btn_reprendre_y - 2,
                        btn_reprendre_x + btn_largeur + 2, btn_reprendre_y + btn_hauteur + 2,
                        makecol(255, 255, 0));
               }

               // Ajouter des instructions pour la navigation
               textout_centre_ex(buffer, police, "Utilisez les flèches et Entrée, ou cliquez",
                               LARGEUR_ECRAN / 2, 350, makecol(200, 200, 200), -1);

               //traiter les clics
               if (clic) {
                   if (souris_sur_bouton(btn_nouvelle_x, btn_nouvelle_y, btn_largeur, btn_hauteur)) {
                       //nouvelle partie, commence au niveau 1
                       joueurs[joueur_actuel].niveau_debloque = 1;
                       sauvegarder_joueurs(joueurs, nb_joueurs);
                       etape_menu = 2;
                   } else if (souris_sur_bouton(btn_reprendre_x, btn_reprendre_y, btn_largeur, btn_hauteur)) {
                       //reprendre la partie au niveau débloqué
                       etape_menu = 2;
                   }

                   //eviter la détection multiple du clic
                   while (mouse_b & 1) {
                       rest(10);
                   }
               }
               break;

           case 2:  //menu principal / sélection de niveau
               textout_centre_ex(buffer, police, "Sélection de niveau", LARGEUR_ECRAN / 2, 130, makecol(255, 255, 255), -1);

               //affichage du pseudo et du niveau débloqué
               char info_joueur[100];
               sprintf(info_joueur, "Joueur: %s - Niveau débloqué: %d",
                       pseudo_actuel, joueurs[joueur_actuel].niveau_debloque);
               textout_centre_ex(buffer, police, info_joueur, LARGEUR_ECRAN / 2, 160, makecol(200, 200, 200), -1);

               int niveau_max = joueurs[joueur_actuel].niveau_debloque;
               int max_options = 5; // 3 niveaux + aide + quitter

               // Gestion des flèches haut/bas
               if (key[KEY_UP] && !touche_haut_pressee) {
                   touche_haut_pressee = 1;
                   selection_menu2 = (selection_menu2 - 1 + max_options) % max_options;
               } else if (!key[KEY_UP]) {
                   touche_haut_pressee = 0;
               }

               if (key[KEY_DOWN] && !touche_bas_pressee) {
                   touche_bas_pressee = 1;
                   selection_menu2 = (selection_menu2 + 1) % max_options;
               } else if (!key[KEY_DOWN]) {
                   touche_bas_pressee = 0;
               }

               // Gestion de la touche Entrée
               if (key[KEY_ENTER] && !touche_entree_pressee) {
                   touche_entree_pressee = 1;

                   if (selection_menu2 < 3) {
                       // Les niveaux (0, 1, 2 = Niveaux 1, 2, 3)
                       int niveau_choisi = selection_menu2 + 1;
                       if (niveau_choisi <= niveau_max) {
                           demarrer_niveau(niveau_choisi);
                       }
                   } else if (selection_menu2 == 3) {
                       // Aide
                       etape_menu = 3;
                   } else if (selection_menu2 == 4) {
                       // Quitter
                       etape_menu = 4;
                   }
               } else if (!key[KEY_ENTER]) {
                   touche_entree_pressee = 0;
               }

               //boutons pour les niveaux (maximum 3 niveaux selon le cahier des charges)
               int btn_niveau_y = 200;
               int espacement_y = 60;
               int i;

               for (i = 1; i <= 3; i++) {
                   char texte_niveau[50];
                   sprintf(texte_niveau, "Niveau %d", i);

                   int est_debloque = (i <= niveau_max);
                   int est_selectionne = (selection_menu2 == i - 1);
                   int couleur_niveau = est_debloque ?
                                        (est_selectionne ? makecol(100, 150, 100) : makecol(50, 100, 50)) :
                                        makecol(70, 70, 70);

                   dessiner_bouton(LARGEUR_ECRAN / 2 - 100, btn_niveau_y, 200, 50,
                                 texte_niveau, couleur_niveau, makecol(255, 255, 255));

                   // Indiquer la sélection avec un rectangle
                   if (est_selectionne) {
                       rect(buffer, LARGEUR_ECRAN / 2 - 102, btn_niveau_y - 2,
                            LARGEUR_ECRAN / 2 + 102, btn_niveau_y + 52,
                            makecol(255, 255, 0));
                   }

                   //ajouter un indicateur pour les niveaux verrouillés
                   if (!est_debloque) {
                       textout_ex(buffer, police, "[Verrouillé]", LARGEUR_ECRAN / 2 + 110, btn_niveau_y + 15, makecol(200, 100, 100), -1);
                   }

                   btn_niveau_y += espacement_y;
               }

               //bouton Aide
               int btn_aide_x = LARGEUR_ECRAN / 2 - 100;
               int btn_aide_y = 380;
               int btn_aide_largeur = 200;
               int btn_aide_hauteur = 50;

               int est_selectionne_aide = (selection_menu2 == 3);
               int couleur_aide = est_selectionne_aide ?
                                 makecol(100, 100, 150) : makecol(50, 50, 100);

               dessiner_bouton(btn_aide_x, btn_aide_y, btn_aide_largeur, btn_aide_hauteur,
                             "Aide", couleur_aide, makecol(255, 255, 255));

               // Indiquer la sélection avec un rectangle
               if (est_selectionne_aide) {
                   rect(buffer, btn_aide_x - 2, btn_aide_y - 2,
                        btn_aide_x + btn_aide_largeur + 2, btn_aide_y + btn_aide_hauteur + 2,
                        makecol(255, 255, 0));
               }

               //bouton Quitter
               int btn_quitter_x = LARGEUR_ECRAN / 2 - 100;
               int btn_quitter_y = 440;
               int btn_quitter_largeur = 200;
               int btn_quitter_hauteur = 50;

               int est_selectionne_quitter = (selection_menu2 == 4);
               int couleur_quitter = est_selectionne_quitter ?
                                    makecol(150, 100, 100) : makecol(100, 50, 50);

               dessiner_bouton(btn_quitter_x, btn_quitter_y, btn_quitter_largeur, btn_quitter_hauteur,
                             "Quitter le jeu", couleur_quitter, makecol(255, 255, 255));

               // Indiquer la sélection avec un rectangle
               if (est_selectionne_quitter) {
                   rect(buffer, btn_quitter_x - 2, btn_quitter_y - 2,
                        btn_quitter_x + btn_quitter_largeur + 2, btn_quitter_y + btn_quitter_hauteur + 2,
                        makecol(255, 255, 0));
               }

               // Ajouter des instructions pour la navigation
               textout_centre_ex(buffer, police, "Utilisez les flèches et Entrée, ou cliquez",
                               LARGEUR_ECRAN / 2, 500, makecol(200, 200, 200), -1);

               //raccourcis pour la soutenance
               textout_centre_ex(buffer, police, "Raccourcis pour la soutenance:", LARGEUR_ECRAN / 2, 510, makecol(255, 200, 100), -1);

               //boutons de raccourcis (F1, F2, F3)
               int btn_raccourci_x = LARGEUR_ECRAN / 2 - 300;
               int btn_raccourci_y = 540;
               int btn_raccourci_largeur = 180;

               for (i = 1; i <= 3; i++) {
                   char texte_raccourci[50];
                   sprintf(texte_raccourci, "F%d: Niveau %d", i, i);

                   int couleur_raccourci = souris_sur_bouton(btn_raccourci_x, btn_raccourci_y, btn_raccourci_largeur, 40) ?
                                          makecol(150, 150, 80) : makecol(100, 100, 50);

                   dessiner_bouton(btn_raccourci_x, btn_raccourci_y, btn_raccourci_largeur, 40,
                                 texte_raccourci, couleur_raccourci, makecol(255, 255, 255));

                   btn_raccourci_x += 200;
               }

               //traiter les clics et les raccourcis clavier
               if (clic) {
                   btn_niveau_y = 200;

                   //gestion des clics sur les niveaux
                   for (i = 1; i <= 3; i++) {
                       if (souris_sur_bouton(LARGEUR_ECRAN / 2 - 100, btn_niveau_y, 200, 50) && i <= niveau_max) {
                           demarrer_niveau(i);
                       }

                       btn_niveau_y += espacement_y;
                   }

                   //gestion des clics sur les raccourcis
                   btn_raccourci_x = LARGEUR_ECRAN / 2 - 300;

                   for (i = 1; i <= 3; i++) {
                       if (souris_sur_bouton(btn_raccourci_x, 540, btn_raccourci_largeur, 40)) {
                           demarrer_niveau(i);
                       }

                       btn_raccourci_x += 200;
                   }

                   //gestion du clic sur le bouton Aide
                   if (souris_sur_bouton(btn_aide_x, btn_aide_y, btn_aide_largeur, btn_aide_hauteur)) {
                       etape_menu = 3;  // Aller à l'écran d'aide
                   }

                   //gestion du clic sur le bouton Quitter
                   if (souris_sur_bouton(btn_quitter_x, btn_quitter_y, btn_quitter_largeur, btn_quitter_hauteur)) {
                       etape_menu = 4;  // Aller à la confirmation de quitter

                       clear_keybuf();

                       while (mouse_b & 1) {
                               rest(10);
                        }
                   }
               }

               //raccourcis clavier pour accéder directement aux niveaux
               if (key[KEY_F1]) demarrer_niveau(1);
               if (key[KEY_F2]) demarrer_niveau(2);
               if (key[KEY_F3]) demarrer_niveau(3);

               break;

           case 3:  //écran d'aide
               afficher_aide();
               break;

           case 4:  //confirmation pour quitter
               demander_confirmation_quitter();
               break;
       }

       //afficher le buffer à l'écran
       blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);

       //petite pause pour éviter une utilisation excessive du CPU
       rest(10);
   }

   //sauvegarder les joueurs avant de quitter
   sauvegarder_joueurs(joueurs, nb_joueurs);

   //nettoyer les ressources d'Allegro
   nettoyer_allegro();

   return 0;
}END_OF_MAIN();