#ifndef NIVEAU1_H
#define NIVEAU1_H

//constantes
#define LARGEUR_ECRAN 800
#define HAUTEUR_ECRAN 600
#define MAX_PSEUDO 20
#define MAX_JOUEURS 100
#define MAX_PICS 3000
#define MAX_OBSTACLES 40

#define GRAVITE_BASE 0.5 //gravité de base
#define PUISSANCE_VOL_BASE -4.0 //force de poussée vers le haut
#define RESISTANCE_AIR 0.95 //coefficient de résistance à l'air
#define INERTIE_MAX 10.0 //limite de vitesse verticale
#include <allegro.h>

//structure pour stocker les info d'un joueur
typedef struct {
    char pseudo[MAX_PSEUDO];
    int niveau_debloque;  //le niveau maximum débloqué par le joueur
} Joueur;

//les variables globales - maintenant déclarées comme extern
extern BITMAP *buffer;
extern BITMAP *fond_menu;
extern FONT *police;
extern Joueur joueurs[MAX_JOUEURS];
extern int nb_joueurs;
extern char pseudo_actuel[MAX_PSEUDO];
extern int joueur_actuel;
extern int etape_menu;  // 0: saisie pseudo, 1: choix nouvelle/reprendre, 2: menu principal, 3: aide, 4: confirmation quitter

extern SAMPLE *son_debut_niveau;  // Pour gamestart.wav
extern SAMPLE *son_game_over;     // Pour gameover.wav
extern SAMPLE *son_victoire;      // Pour levelcomplete.wav
extern MIDI *musique_menu;        // Pour menu.mid
extern MIDI *musique_niveau1;     // Pour niveau1.mid
extern int musique_activee;
extern int musique_menu_en_cours;
extern int musique_niveau_en_cours;

// Variables pour la navigation au clavier dans les menus
extern int selection_menu1; // Pour l'étape 1 (nouvelle partie/reprendre)
extern int selection_menu2; // Pour l'étape 2 (menu principal)
extern int selection_quitter; // Pour l'étape 4 (confirmation quitter)

// Déclarer la fonction min comme inline pour éviter les définitions multiples
static inline int min(int a, int b) {
    return (a < b) ? a : b;
}

//prototypes de fonctions
void initialiser_allegro();
void nettoyer_allegro();
void saisir_pseudo(char *pseudo);
int charger_joueurs(Joueur *joueurs);
void sauvegarder_joueurs(Joueur *joueurs, int nb_joueurs);
int trouver_joueur(Joueur *joueurs, int nb_joueurs, char *pseudo);
void ajouter_joueur(Joueur *joueurs, int *nb_joueurs, char *pseudo);
void demarrer_niveau(int niveau);
void afficher_aide();
void demander_confirmation_quitter();
void demarrer_niveau(int niveau);
void niveau1();
int distance(int x1, int y1, int x2, int y2);

#endif //NIVEAU1_H
