#include "niveau1.h"
#include <allegro.h>
#include <math.h>
#include <stdio.h>
#include "audio.h"
#include "menu.h"

void niveau1() {
    // Variable pour gérer les recommencements
    int recommencer = 1;
    int taille_niveau = 7000;

    // Stopper toute musique en cours avant d'en jouer une nouvelle
    stop_midi();
    musique_menu_en_cours = 0;
    musique_niveau_en_cours = 0;

    // Changer la musique pour celle du niveau
    jouer_musique(musique_niveau1, &musique_niveau_en_cours);

    // Jouer le son de début de niveau
    jouer_son(son_debut_niveau);

    // Charger les sprites du personnage
    BITMAP *sprites_perso[4];
    sprites_perso[0] = load_bitmap("perso 1.bmp", NULL);
    sprites_perso[1] = load_bitmap("perso 2.bmp", NULL);
    sprites_perso[2] = load_bitmap("perso 3.bmp", NULL);
    sprites_perso[3] = load_bitmap("perso 4.bmp", NULL);

    int taille_personnage = 15;

    // Vérifier que les sprites ont été chargés correctement
    int sprites_ok = 1;
    int i;
    for (i = 0; i < 4; i++) {
        if (!sprites_perso[i]) {
            sprites_ok = 0;
            allegro_message("Erreur: Impossible de charger perso %d.bmp", i+1);
            break;
        }
    }

    // Chargement du fond forestier style Badland
    BITMAP *fond_defilant = load_bitmap("fond.bmp", NULL);

    if (!fond_defilant) {
        fond_defilant = create_bitmap(LARGEUR_ECRAN*3, HAUTEUR_ECRAN);
        clear_to_color(fond_defilant, makecol(30, 30, 50)); // Fond bleu nuit

        // Ajouter des éléments de décor
        for (i = 0; i < 50; i++) {
            int x = rand() % (LARGEUR_ECRAN*3);
            int y = rand() % HAUTEUR_ECRAN;
            int taille = rand() % 10 + 5;
            // Plantes étranges style Badland
            ellipsefill(fond_defilant, x, y, taille, taille*2, makecol(20, 50, 20));
            ellipsefill(fond_defilant, x+taille/2, y-taille/2, taille/2, taille, makecol(30, 70, 30));
        }

        // Ajouter des particules lumineuses
        for (i = 0; i < 100; i++) {
            int x = rand() % (LARGEUR_ECRAN*3);
            int y = rand() % HAUTEUR_ECRAN;
            int taille = rand() % 3 + 1;
            circlefill(fond_defilant, x, y, taille, makecol(150, 200, 255));
        }
    }

    // Création d'un décor organique qui défile avec le fond
    BITMAP *decor_fixe = create_bitmap(taille_niveau, HAUTEUR_ECRAN);
    clear_to_color(decor_fixe, makecol(255, 0, 255)); // Couleur de transparence

    int pics[MAX_PICS][4]; // x, y, largeur, hauteur
    int nb_pics = 0;

    int hauteur_bordure = 50;

    rectfill(decor_fixe, 0, 0, taille_niveau, hauteur_bordure, makecol(0, 0, 0)); // Haut
    rectfill(decor_fixe, 0, HAUTEUR_ECRAN - hauteur_bordure, taille_niveau, HAUTEUR_ECRAN, makecol(0, 0, 0)); // Bas

    int x = 0;
    while (x < decor_fixe->w - 100 && nb_pics + 2 < MAX_PICS) {
        int largeur_pic = 40 + rand() % 60;
        int hauteur_haut = 40 + rand() % 60;
        int hauteur_bas = 40 + rand() % 60;

        triangle(decor_fixe,
                x, 0,
                x + largeur_pic, 0,
                x + largeur_pic / 2, hauteur_bordure + hauteur_haut,
                makecol(0, 0, 0));

        // Ajout dans pics (haut)
        pics[nb_pics][0] = x;
        pics[nb_pics][1] = 0;
        pics[nb_pics][2] = largeur_pic;
        pics[nb_pics][3] = hauteur_bordure + hauteur_haut;
        nb_pics++;

        // Dessin en bas : stalagmite ou vague
       triangle(decor_fixe,
                x, HAUTEUR_ECRAN,
                x + largeur_pic, HAUTEUR_ECRAN,
                x + largeur_pic / 2, HAUTEUR_ECRAN - hauteur_bordure - hauteur_bas,
                makecol(0, 0, 0));


        // Ajout dans pics (bas)
        pics[nb_pics][0] = x;
        pics[nb_pics][1] = HAUTEUR_ECRAN - hauteur_bordure - hauteur_bas;
        pics[nb_pics][2] = largeur_pic;
        pics[nb_pics][3] = hauteur_bordure + hauteur_bas;
        nb_pics++;

        x += largeur_pic - 15; // Pour une variation naturelle
    }

    while (recommencer) {
        // Réinitialiser recommencer
        recommencer = 0;

        // Variables pour le niveau
        int sortie = 0;
        int game_over = 0;
        int niveau_termine = 0;
        int sorti_gauche = 0;

        int position_joueur_x = LARGEUR_ECRAN / 4; // Position fixe horizontale
        int position_joueur_y = HAUTEUR_ECRAN / 2; // Position initiale verticale

        float vitesse_y = 0;           // Vitesse verticale
        float gravite = 0.4;           // Gravité plus légère pour un gameplay plus fluide
        float puissance_vol = -3.5;    // Force de vol vers le haut

        float resistance_air = 0.92;    // Plus de résistance pour un contrôle plus précis
        float inertie_max = 8.0;       // Limite de vitesse verticale

        int taille_joueur = taille_personnage; // Taille du joueur réduite
        int sprite_actuel = 0;         // Sprite par défaut
        int anim_timer = 0;            // Timer pour l'animation
        int au_sol = 0;                // Indique si le joueur est au sol
        int touche_echap_pressee = 0;  // Éviter les déclenchements multiples
        int touche_m_pressee = 0;      // Pour gérer la touche M (musique)
        int message_affiche = 0;       // Affichage d'un message
        int message_timer = 0;         // Durée d'affichage du message
        int phase_tutorial = 0;        // Phase du tutoriel

        // Position des obstacles qui défilent
        int position_decor = 0;
        int scroll_active = 0;        // Le scroll n'est pas encore actif
        int vitesse_scroll = 4;       // Vitesse de défilement légèrement augmentée

        // Définition des obstacles du niveau
        int obstacles[MAX_OBSTACLES][5];
        int nb_obstacles = 0;

        // Obstacles organiques style Badland
        for (i = 0; i < 15; i++) {
            obstacles[nb_obstacles][0] = 800 + i * 200 + rand() % 100;  // Position X
            obstacles[nb_obstacles][1] = hauteur_bordure + 30 + (rand() % (HAUTEUR_ECRAN - 2*hauteur_bordure - 60));  // Position Y
            obstacles[nb_obstacles][2] = 40 + rand() % 60;   // Largeur
            obstacles[nb_obstacles][3] = 40 + rand() % 60;   // Hauteur
            obstacles[nb_obstacles][4] = 0;    // Type 0 (bloc normal)
            nb_obstacles++;
        }

        // Ajouter quelques obstacles mortels (rouges)
        for (i = 0; i < 5; i++) {
            obstacles[nb_obstacles][0] = 1200 + i * 400 + rand() % 150;
            obstacles[nb_obstacles][1] = hauteur_bordure + 30 + (rand() % (HAUTEUR_ECRAN - 2*hauteur_bordure - 60));
            obstacles[nb_obstacles][2] = 30 + rand() % 40;
            obstacles[nb_obstacles][3] = 30 + rand() % 40;
            obstacles[nb_obstacles][4] = 1;    // Type 1 (mortel)
            nb_obstacles++;
        }

        // Position de la sortie du niveau
        int sortie_x = 5000;  // Position X de la sortie
        int sortie_y = HAUTEUR_ECRAN / 2;  // Position Y de la sortie

        // Durée du niveau (60 fps * 60 secondes = 3600 frames pour 1 minute)
        int duree_niveau = 3600;
        int timer_niveau = 0;

        // Messages tutoriels
        char *messages_tutoriel[] = {
            "Bienvenue dans BadLand! Appuie sur ESPACE pour voler.",
            "Controle ta hauteur pour eviter les obstacles noirs!",
            "Attention aux obstacles rouges - ils sont mortels!",
            "Tiens bon jusqu'a la sortie ou jusqu'au temps ecoule.",
            "Bravo! Tu as presque termine le niveau!"
        };

        // Boucle principale du niveau
        while (!sortie) {
            // Gestion de la touche M pour activer/désactiver la musique
            if (key[KEY_M] && !touche_m_pressee) {
                touche_m_pressee = 1;
                basculer_musique();
            }
            else if (!key[KEY_M]) {
                touche_m_pressee = 0;
            }

            // Gestion du menu pause
            if (key[KEY_ESC] && !touche_echap_pressee) {
                touche_echap_pressee = 1;
                int choix_menu = afficher_menu_pause();
                if (choix_menu == 1) {
                    sortie = 1;
                }
            }
            else if (!key[KEY_ESC]) {
                touche_echap_pressee = 0;
            }

            // Activer le scroll au premier appui sur espace
            if (key[KEY_SPACE] && !scroll_active) {
                scroll_active = 1;
                message_affiche = 1;
                message_timer = 180;  // Durée d'affichage de 3 secondes
                phase_tutorial = 0;   // Premier message
            }

            // Gestion du vol du personnage
            if (scroll_active) {
                // Gestion de la gravité
                if (key[KEY_SPACE]) {
                    // Application de la force de vol (vers le haut)
                    vitesse_y += puissance_vol;

                    // Ajouter un effet de particules quand on vole
                    if (rand() % 3 == 0) {
                        int part_x = position_joueur_x - taille_joueur - rand() % 5;
                        int part_y = position_joueur_y + rand() % (taille_joueur*2) - taille_joueur;
                        putpixel(buffer, part_x, part_y, makecol(150, 200, 255));
                    }
                } else {
                    // Application de la gravité (vers le bas)
                    vitesse_y += gravite;
                }

                // Limiter la vitesse à l'inertie maximale
                if (vitesse_y > inertie_max) vitesse_y = inertie_max;
                if (vitesse_y < -inertie_max) vitesse_y = -inertie_max;

                // Appliquer la résistance de l'air
                vitesse_y *= resistance_air;

                // Mettre à jour la position verticale
                position_joueur_y += vitesse_y;

                // Limiter aux bordures supérieure et inférieure
                if (position_joueur_y < hauteur_bordure + taille_joueur) {
                    position_joueur_y = hauteur_bordure + taille_joueur;
                    vitesse_y = 0;
                }
                if (position_joueur_y > HAUTEUR_ECRAN - hauteur_bordure - taille_joueur) {
                    position_joueur_y = HAUTEUR_ECRAN - hauteur_bordure - taille_joueur;
                    vitesse_y = 0;
                    au_sol = 1;
                } else {
                    au_sol = 0;
                }

                // Avancer le décor (scrolling)
                position_decor += vitesse_scroll;

                // Vérification des collisions avec les obstacles
                for (i = 0; i < nb_obstacles; i++) {
                    int obstacle_x = obstacles[i][0] - position_decor;
                    int obstacle_y = obstacles[i][1];
                    int obstacle_largeur = obstacles[i][2];
                    int obstacle_hauteur = obstacles[i][3];
                    int obstacle_type = obstacles[i][4];

                    // Vérifier si obstacle visible à l'écran
                    if (obstacle_x + obstacle_largeur > 0 && obstacle_x < LARGEUR_ECRAN) {
                        // Vérifier collision
                        if (position_joueur_x + taille_joueur > obstacle_x &&
                            position_joueur_x - taille_joueur < obstacle_x + obstacle_largeur &&
                            position_joueur_y + taille_joueur > obstacle_y &&
                            position_joueur_y - taille_joueur < obstacle_y + obstacle_hauteur) {

                            // Si c'est un obstacle mortel
                            if (obstacle_type == 1) {
                                game_over = 1;
                                jouer_son(son_game_over);
                                sortie = 1;
                            } else {
                                // Bloquer le joueur contre l'obstacle
                                int pen_gauche = (position_joueur_x + taille_joueur) - obstacle_x;
                                int pen_droite = (obstacle_x + obstacle_largeur) - (position_joueur_x - taille_joueur);
                                int pen_haut = (position_joueur_y + taille_joueur) - obstacle_y;
                                int pen_bas = (obstacle_y + obstacle_hauteur) - (position_joueur_y - taille_joueur);

                                if (pen_gauche <= pen_droite && pen_gauche <= pen_haut && pen_gauche <= pen_bas) {
                                    position_joueur_x = obstacle_x - taille_joueur;
                                } else if (pen_droite <= pen_gauche && pen_droite <= pen_haut && pen_droite <= pen_bas) {
                                    position_joueur_x = obstacle_x + obstacle_largeur + taille_joueur;
                                } else if (pen_haut <= pen_gauche && pen_haut <= pen_droite && pen_haut <= pen_bas) {
                                    position_joueur_y = obstacle_y - taille_joueur;
                                    vitesse_y = 0;
                                    au_sol = 1;
                                } else {
                                    position_joueur_y = obstacle_y + obstacle_hauteur + taille_joueur;
                                    vitesse_y = 1.5;  // Légère impulsion vers le bas
                                }
                            }
                        }
                    }
                }

                // Vérifier les collisions avec les pics
                for (i = 0; i < nb_pics; i++) {
                    int pic_x = pics[i][0];
                    int pic_y = pics[i][1];
                    int pic_largeur = pics[i][2];
                    int pic_hauteur = pics[i][3];

                    if (position_joueur_x + taille_joueur > pic_x &&
                        position_joueur_x - taille_joueur < pic_x + pic_largeur &&
                        position_joueur_y + taille_joueur > pic_y &&
                        position_joueur_y - taille_joueur < pic_y + pic_hauteur) {

                        int point_triangle_x = pic_x + pic_largeur/2;
                        int point_triangle_y;

                        if (pic_y < HAUTEUR_ECRAN/2) {
                            point_triangle_y = pic_y + pic_hauteur;
                        } else {
                            point_triangle_y = pic_y;
                        }

                        int distance_pointe = distance(position_joueur_x, position_joueur_y, point_triangle_x, point_triangle_y);
                        if (distance_pointe < taille_joueur + 8) {
                            if (pic_y < HAUTEUR_ECRAN/2) {
                                position_joueur_y = pic_y + pic_hauteur + taille_joueur;
                                vitesse_y = 1.5;
                            } else {
                                position_joueur_y = pic_y - taille_joueur;
                                vitesse_y = -1.5;
                            }
                            break;
                        }
                    }
                }

                // Vérifier si le joueur est sorti à gauche de l'écran
                if (position_joueur_x < -taille_joueur) {
                    game_over = 1;
                    sorti_gauche = 1;
                    jouer_son(son_game_over);
                    sortie = 1;
                }

                // Vérifier si le joueur a atteint la sortie du niveau
                int sortie_ecran_x = sortie_x - position_decor;
                if (sortie_ecran_x < LARGEUR_ECRAN &&
                    abs(position_joueur_x - sortie_ecran_x) < 50 &&
                    abs(position_joueur_y - sortie_y) < 50) {

                    niveau_termine = 1;
                    jouer_son(son_victoire);
                    sortie = 1;
                }

                // Incrémenter le timer du niveau
                timer_niveau++;

                // Si le niveau dure suffisamment longtemps
                if (timer_niveau >= duree_niveau) {
                    niveau_termine = 1;
                    jouer_son(son_victoire);
                    sortie = 1;
                }

                // Afficher des messages à différents moments
                if (timer_niveau == 600) {
                    message_affiche = 1;
                    message_timer = 180;
                    phase_tutorial = 1;
                } else if (timer_niveau == 1800) {
                    message_affiche = 1;
                    message_timer = 180;
                    phase_tutorial = 2;
                } else if (timer_niveau == 2700) {
                    message_affiche = 1;
                    message_timer = 180;
                    phase_tutorial = 3;
                } else if (timer_niveau == 3300) {
                    message_affiche = 1;
                    message_timer = 180;
                    phase_tutorial = 4;
                }
            }

            // Décrémenter le timer du message
            if (message_timer > 0) {
                message_timer--;
            } else {
                message_affiche = 0;
            }

            // Animation du personnage
            anim_timer++;
            if (anim_timer >= 5) {
                anim_timer = 0;
                if (au_sol) {
                    sprite_actuel = 3;
                } else if (vitesse_y < 0) {
                    sprite_actuel = (sprite_actuel == 0) ? 1 : 0;
                } else {
                    sprite_actuel = 2;
                }
            }

            // Effacer le buffer avant de dessiner
            clear_to_color(buffer, makecol(0, 0, 0));

            // Dessiner le fond défilant
            if (fond_defilant) {
                int fond_largeur = fond_defilant->w;
                int decalage = position_decor % fond_largeur;

                // Départ à -decalage pour que l’image soit bien alignée
                for (int x = -decalage; x < taille_niveau; x += fond_largeur) {
                    draw_sprite(buffer, fond_defilant, x, 0);
                }
            }


            // Dessiner les obstacles défilants avec effet style Badland
            for (i = 0; i < nb_obstacles; i++) {
                int obstacle_x = obstacles[i][0] - position_decor;
                int obstacle_y = obstacles[i][1];
                int obstacle_largeur = obstacles[i][2];
                int obstacle_hauteur = obstacles[i][3];
                int obstacle_type = obstacles[i][4];

                if (obstacle_x + obstacle_largeur > 0 && obstacle_x < LARGEUR_ECRAN) {
                    if (obstacle_type == 0) {
                        // Obstacle standard avec effet organique
                        rectfill(buffer, obstacle_x, obstacle_y, obstacle_x + obstacle_largeur, obstacle_y + obstacle_hauteur, makecol(20, 20, 30));
                        rectfill(buffer, obstacle_x+2, obstacle_y+2, obstacle_x + obstacle_largeur-2, obstacle_y + obstacle_hauteur-2, makecol(30, 30, 40));
                    } else if (obstacle_type == 1) {
                        // Obstacle mortel avec effet de danger
                        rectfill(buffer, obstacle_x, obstacle_y, obstacle_x + obstacle_largeur, obstacle_y + obstacle_hauteur, makecol(80, 0, 0));
                        rectfill(buffer, obstacle_x+2, obstacle_y+2, obstacle_x + obstacle_largeur-2, obstacle_y + obstacle_hauteur-2, makecol(120, 0, 0));
                    }
                }
            }

            // Dessiner la sortie avec effet lumineux
            int sortie_ecran_x = sortie_x - position_decor;
            if (sortie_ecran_x < LARGEUR_ECRAN && sortie_ecran_x > -50) {
                for (int j = 0; j < 3; j++) {
                    circlefill(buffer, sortie_ecran_x, sortie_y, 30 - j*10, makecol(0, 150-j*50, 0));
                }
                textout_centre_ex(buffer, font, "SORTIE", sortie_ecran_x, sortie_y - 40, makecol(0, 255, 0), -1);
            }

            // Dessiner le personnage avec la nouvelle taille réduite
            if (sprites_ok) {
                int sprite_taille = taille_joueur * 2; // Taille réduite
                BITMAP *temp = create_bitmap(sprite_taille * 2, sprite_taille * 2);
                clear_to_color(temp, makecol(255, 0, 255));

                stretch_blit(sprites_perso[sprite_actuel], temp,
                           0, 0, sprites_perso[sprite_actuel]->w, sprites_perso[sprite_actuel]->h,
                           0, 0, sprite_taille * 2, sprite_taille * 2);

                draw_sprite(buffer, temp, position_joueur_x - sprite_taille, position_joueur_y - sprite_taille);
                destroy_bitmap(temp);
            } else {
                circlefill(buffer, position_joueur_x, position_joueur_y, taille_joueur, makecol(0, 0, 0));
            }

            // Dessiner le décor fixe par-dessus tout
            //draw_sprite(buffer, decor_fixe, 0, 0);
            int decor_decalage = position_decor % decor_fixe->w;
            for (int x = -decor_decalage; x < taille_niveau; x += decor_fixe->w) {
                draw_sprite(buffer, decor_fixe, x, 0);
            }

            // Afficher le temps écoulé avec style Badland
            textprintf_ex(buffer, font, 10, 10, makecol(200, 200, 255), -1,
                          "TEMPS: %d:%02d", timer_niveau / 3600, (timer_niveau % 3600) / 60);

            // Afficher les instructions
            if (!scroll_active) {
                textout_centre_ex(buffer, font, "APPUYEZ SUR ESPACE POUR COMMENCER",
                                LARGEUR_ECRAN / 2, HAUTEUR_ECRAN - 50,
                                makecol(200, 200, 255), -1);
            }

            // Afficher le message tutoriel avec style
            if (message_affiche) {
                // Fond semi-transparent
                rectfill(buffer, 50, HAUTEUR_ECRAN - 100, LARGEUR_ECRAN - 50, HAUTEUR_ECRAN - 40, makecol(0, 0, 60));
                rect(buffer, 50, HAUTEUR_ECRAN - 100, LARGEUR_ECRAN - 50, HAUTEUR_ECRAN - 40, makecol(100, 100, 255));

                // Afficher le message
                textout_centre_ex(buffer, font, messages_tutoriel[phase_tutorial],
                                LARGEUR_ECRAN / 2, HAUTEUR_ECRAN - 80,
                                makecol(200, 200, 255), -1);
            }

            // Afficher à l'écran
            blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);

            // Petite pause pour limiter le framerate
            rest(16);
        }

        // Gestion de fin de niveau
        if (niveau_termine) {
            // Écran de victoire style Badland
            clear_to_color(buffer, makecol(0, 0, 30));

            textout_centre_ex(buffer, font, "NIVEAU COMPLETE!",
                            LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2 - 50,
                            makecol(100, 255, 100), -1);

            textout_centre_ex(buffer, font, "Tu as reussi le niveau 1!",
                            LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2,
                            makecol(200, 200, 255), -1);

            textout_centre_ex(buffer, font, "Appuyez sur une touche pour continuer",
                            LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2 + 50,
                            makecol(150, 150, 200), -1);

            blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);
            readkey();

            // Mettre à jour le niveau débloqué
            if (joueur_actuel >= 0 && joueurs[joueur_actuel].niveau_debloque < 2) {
                joueurs[joueur_actuel].niveau_debloque = 2;
                sauvegarder_joueurs(joueurs, nb_joueurs);
            }
        }
        else if (sorti_gauche) {
            clear_to_color(buffer, makecol(30, 0, 0));

            textout_centre_ex(buffer, font, "TU ES SORTI DE L'ECRAN!",
                           LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2 - 40,
                           makecol(255, 100, 100), -1);

            textout_centre_ex(buffer, font, "RECOMMENCE!",
                           LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2,
                           makecol(255, 150, 150), -1);

            textout_centre_ex(buffer, font, "Appuyez sur une touche pour recommencer",
                           LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2 + 50,
                           makecol(200, 200, 200), -1);

            blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);
            readkey();
            recommencer = 1;
        }
        else if (game_over) {
            clear_to_color(buffer, makecol(30, 0, 0));

            textout_centre_ex(buffer, font, "GAME OVER",
                           LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2,
                           makecol(255, 100, 100), -1);

            textout_centre_ex(buffer, font, "Appuyez sur une touche pour revenir au menu",
                           LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2 + 30,
                           makecol(200, 200, 200), -1);

            blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);
            readkey();
        }
    }

    // Libérer la mémoire
    for (i = 0; i < 4; i++) {
        if (sprites_perso[i]) {
            destroy_bitmap(sprites_perso[i]);
        }
    }

    if (fond_defilant) {
        destroy_bitmap(fond_defilant);
    }

    destroy_bitmap(decor_fixe);

    // Arrêter la musique du niveau
    stop_midi();
    musique_niveau_en_cours = 0;

    // Restaurer la musique du menu
    jouer_musique(musique_menu, &musique_menu_en_cours);
}

int distance(int x1, int y1, int x2, int y2) {
    return (int)sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

void demarrer_niveau(int niveau) {
    switch (niveau) {
        case 1:
            niveau1();
            break;
        case 2:
            clear_to_color(buffer, makecol(0, 0, 0));
            textout_centre_ex(buffer, police, "Niveau 2 pas encore implémenté", LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2, makecol(255, 255, 255), -1);
            textout_centre_ex(buffer, police, "Appuyez sur une touche pour revenir au menu", LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2 + 50, makecol(200, 200, 200), -1);
            blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);
            readkey();
            break;
        case 3:
            clear_to_color(buffer, makecol(0, 0, 0));
            textout_centre_ex(buffer, police, "Niveau 3 pas encore implémenté", LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2, makecol(255, 255, 255), -1);
            textout_centre_ex(buffer, police, "Appuyez sur une touche pour revenir au menu", LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2 + 50, makecol(200, 200, 200), -1);
            blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);
            readkey();
            break;
        default:
            clear_to_color(buffer, makecol(0, 0, 0));
            textout_centre_ex(buffer, police, "Niveau inconnu", LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2, makecol(255, 255, 255), -1);
            textout_centre_ex(buffer, police, "Appuyez sur une touche pour revenir au menu", LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2 + 50, makecol(200, 200, 200), -1);
            blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);
            readkey();
    }
}