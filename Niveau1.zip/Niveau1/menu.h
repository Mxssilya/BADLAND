
#ifndef MENU_H
#define MENU_H

void afficher_aide();
void demander_confirmation_quitter();
int afficher_menu_pause();
void dessiner_fond();
void dessiner_bouton(int x, int y, int largeur, int hauteur, char *texte, int couleur, int couleur_texte);
int souris_sur_bouton(int x, int y, int largeur, int hauteur);

#endif //MENU_H