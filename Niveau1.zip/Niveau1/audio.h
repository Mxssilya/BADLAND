
#ifndef AUDIO_H
#define AUDIO_H

void initialiser_audio();
void nettoyer_audio();
void jouer_musique(MIDI *musique, int *en_cours);
void jouer_son(SAMPLE *son);
void basculer_musique();

#endif //AUDIO_H
