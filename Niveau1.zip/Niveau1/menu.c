#include "menu.h"
#include <allegro.h>

#include "niveau1.h"

void dessiner_fond() {

    if(fond_menu) {
        blit(fond_menu, buffer, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);
    }else {
        clear_to_color(buffer, makecol(20, 20, 30));  // Fond bleu foncé
    }

    //titre du jeu
    //rectfill(buffer, LARGEUR_ECRAN/2 - 150, 40, LARGEUR_ECRAN/2 + 150, 90, makecol(0, 0, 128));
    textout_centre_ex(buffer, police, "BADLAND", LARGEUR_ECRAN / 2, 50, makecol(255, 255, 255), -1);
    textout_centre_ex(buffer, police, "Projet Allegro ING1 2025", LARGEUR_ECRAN / 2, 80, makecol(200, 200, 200), -1);
}

void dessiner_bouton(int x, int y, int largeur, int hauteur, char *texte, int couleur, int couleur_texte) {
    rectfill(buffer, x, y, x + largeur, y + hauteur, couleur);
    rect(buffer, x, y, x + largeur, y + hauteur, makecol(255, 255, 255));

    //centre le texte sur le bouton
    int text_x = x + (largeur - text_length(police, texte)) / 2;
    int text_y = y + (hauteur - text_height(police)) / 2;

    textout_ex(buffer, police, texte, text_x, text_y, couleur_texte, -1);
}

int souris_sur_bouton(int x, int y, int largeur, int hauteur) {
    return (mouse_x >= x && mouse_x <= x + largeur &&
            mouse_y >= y && mouse_y <= y + hauteur);
}

void afficher_aide() {
    int sortie = 0;

    while (!sortie) {
        //on dessine le fond
        dessiner_fond();

        //ancadré "AIDE"
        textout_centre_ex(buffer, police, "AIDE", LARGEUR_ECRAN / 2, 130, makecol(255, 220, 100), -1);

        //instructions du jeu
        int y = 180;
        int espacement = 25;

        textout_centre_ex(buffer, police, "COMMENT JOUER", LARGEUR_ECRAN / 2, y, makecol(200, 255, 200), -1);
        y += espacement * 2;

        textout_ex(buffer, police, "1. Appuyez sur la barre ESPACE pour faire voler le personnage.", 120, y, makecol(255, 255, 255), -1);
        y += espacement;

        textout_ex(buffer, police, "2. Relâchez la barre ESPACE pour laisser redescendre le personnage.", 120, y, makecol(255, 255, 255), -1);
        y += espacement;

        textout_ex(buffer, police, "3. Évitez les obstacles et le décor noir qui est infranchissable.", 120, y, makecol(255, 255, 255), -1);
        y += espacement;

        textout_ex(buffer, police, "4. Collectez des bonus (indiqués par des cercles colorés) pour obtenir", 120, y, makecol(255, 255, 255), -1);
        y += espacement;

        textout_ex(buffer, police, "   différents avantages : taille, vitesse, clones, etc.", 120, y, makecol(255, 255, 255), -1);
        y += espacement;

        textout_ex(buffer, police, "5. Atteignez la sortie (cercle vert) pour passer au niveau suivant.", 120, y, makecol(255, 255, 255), -1);
        y += espacement * 2;

        textout_ex(buffer, police, "Attention : si vous êtes bloqué par le décor et sortez de l'écran à", 120, y, makecol(255, 200, 200), -1);
        y += espacement;

        textout_ex(buffer, police, "gauche, vous perdez et devez recommencer le niveau.", 120, y, makecol(255, 200, 200), -1);
        y += espacement * 2;

        textout_ex(buffer, police, "Raccourcis : F1, F2, F3 pour accéder directement aux niveaux 1, 2, 3.", 120, y, makecol(200, 200, 255), -1);
        y += espacement;

        textout_ex(buffer, police, "Appuyez sur Échap pour quitter la partie à tout moment.", 120, y, makecol(200, 200, 255), -1);

        //pour le bouton retour
        int btn_retour_x = LARGEUR_ECRAN / 2 - 100;
        int btn_retour_y = HAUTEUR_ECRAN - 80;
        int btn_largeur = 200;
        int btn_hauteur = 50;

        int couleur_retour = souris_sur_bouton(btn_retour_x, btn_retour_y, btn_largeur, btn_hauteur) ?
                            makecol(100, 100, 150) : makecol(70, 70, 120);

        dessiner_bouton(btn_retour_x, btn_retour_y, btn_largeur, btn_hauteur,
                      "Retour au menu", couleur_retour, makecol(255, 255, 255));

        blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);

        //gestion des entrées
        if (key[KEY_ESC]) {
            sortie = 1;
        }

        if (mouse_b & 1) {
            if (souris_sur_bouton(btn_retour_x, btn_retour_y, btn_largeur, btn_hauteur)) {
                sortie = 1;
            }

            //pour éviter la détection de plusieurs clics
            while (mouse_b & 1) {
                rest(10);
            }
        }

        rest(10);
    }

    //retour au menu principal
    etape_menu = 2;
}

void demander_confirmation_quitter() {
    int sortie = 0;
    static int touche_gauche_pressee = 0;
    static int touche_droite_pressee = 0;
    static int touche_entree_pressee = 0;

    // Vider la file d'attente du clavier AVANT d'entrer dans la boucle
    clear_keybuf();

    // Petite pause pour éviter que les entrées précédentes ne soient détectées
    rest(100);

    while (!sortie) {
        // Dessiner le fond
        dessiner_fond();

        // Message de confirmation
        textout_centre_ex(buffer, police, "Êtes-vous sûr de vouloir quitter le jeu ?",
                        LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2 - 50, makecol(255, 255, 255), -1);

        // Bouton Oui
        int btn_oui_x = LARGEUR_ECRAN / 2 - 150;
        int btn_oui_y = HAUTEUR_ECRAN / 2 + 20;
        int btn_largeur = 120;
        int btn_hauteur = 50;

        int couleur_oui = selection_quitter == 1 ? makecol(150, 100, 100) : makecol(100, 50, 50);

        dessiner_bouton(btn_oui_x, btn_oui_y, btn_largeur, btn_hauteur,
                      "Oui", couleur_oui, makecol(255, 255, 255));

        // Indiquer la sélection avec un rectangle
        if (selection_quitter == 1) {
            rect(buffer, btn_oui_x - 2, btn_oui_y - 2, btn_oui_x + btn_largeur + 2, btn_oui_y + btn_hauteur + 2, makecol(255, 255, 0));
        }

        // Bouton Non
        int btn_non_x = LARGEUR_ECRAN / 2 + 30;
        int btn_non_y = HAUTEUR_ECRAN / 2 + 20;

        int couleur_non = selection_quitter == 0 ? makecol(100, 150, 100) : makecol(50, 100, 50);

        dessiner_bouton(btn_non_x, btn_non_y, btn_largeur, btn_hauteur,
                      "Non", couleur_non, makecol(255, 255, 255));

        // Indiquer la sélection avec un rectangle
        if (selection_quitter == 0) {
            rect(buffer, btn_non_x - 2, btn_non_y - 2, btn_non_x + btn_largeur + 2, btn_non_y + btn_hauteur + 2, makecol(255, 255, 0));
        }

        // Instructions pour la navigation
        textout_centre_ex(buffer, police, "Utilisez les flèches et Entrée, ou cliquez",
                        LARGEUR_ECRAN / 2, HAUTEUR_ECRAN / 2 + 100, makecol(200, 200, 200), -1);

        // Afficher à l'écran
        blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);

        // Gestion des flèches gauche/droite
        if (key[KEY_LEFT] && !touche_gauche_pressee) {
            touche_gauche_pressee = 1;
            selection_quitter = 1;  // Sélectionner Oui (à gauche)
        } else if (!key[KEY_LEFT]) {
            touche_gauche_pressee = 0;
        }

        if (key[KEY_RIGHT] && !touche_droite_pressee) {
            touche_droite_pressee = 1;
            selection_quitter = 0;  // Sélectionner Non (à droite)
        } else if (!key[KEY_RIGHT]) {
            touche_droite_pressee = 0;
        }

        // Gestion de la touche Entrée
        if (key[KEY_ENTER] && !touche_entree_pressee) {
            touche_entree_pressee = 1;

            if (selection_quitter == 1) {
                // Oui sélectionné - quitter le jeu
                sauvegarder_joueurs(joueurs, nb_joueurs);
                nettoyer_allegro();
                exit(0);
            } else {
                // Non sélectionné - retour au menu principal
                sortie = 1;
                etape_menu = 2;

                // IMPORTANT: Désactiver les touches pour éviter le double déclenchement
                clear_keybuf();
                rest(200); // Ajouter un délai pour éviter les déclenchements accidentels
            }
        } else if (!key[KEY_ENTER]) {
            touche_entree_pressee = 0;
        }

        // Pour la touche Échap - retourner au menu principal
        if (key[KEY_ESC]) {
            sortie = 1;
            etape_menu = 2;

            // IMPORTANT: Désactiver les touches pour éviter le double déclenchement
            clear_keybuf();
            rest(200); // Ajouter un délai pour éviter les déclenchements accidentels
        }

        // Gestion des clics de souris
        if (mouse_b & 1) {
            if (souris_sur_bouton(btn_oui_x, btn_oui_y, btn_largeur, btn_hauteur)) {
                // Oui sélectionné - quitter le jeu
                sauvegarder_joueurs(joueurs, nb_joueurs);
                nettoyer_allegro();
                exit(0);
            }
            else if (souris_sur_bouton(btn_non_x, btn_non_y, btn_largeur, btn_hauteur)) {
                // Non sélectionné - retour au menu principal
                sortie = 1;
                etape_menu = 2;

                // IMPORTANT: Désactiver les touches pour éviter le double déclenchement
                clear_keybuf();
                rest(200); // Ajouter un délai pour éviter les déclenchements accidentels
            }

            // Éviter la détection de plusieurs clics
            while (mouse_b & 1) {
                rest(10);
            }
        }

        // Petite pause pour limiter l'utilisation du CPU
        rest(10);
    }

    // Vider à nouveau la file d'attente du clavier avant de sortir
    clear_keybuf();
}

int afficher_menu_pause() {
    int sortie = 0;
    int choix = 0;  // 0 = continuer, 1 = quitter

    //on vide la file d'attente du clavier
    clear_keybuf();

    //on prend une capture d'écran du jeu pour l'arrière-plan
    BITMAP *capture = create_bitmap(LARGEUR_ECRAN, HAUTEUR_ECRAN);
    blit(buffer, capture, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);

    while (!sortie) {
        //dessiner l'arrière-plan (jeu en pause)
        blit(capture, buffer, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);

        //assombrissement de l'écran (semi-transparent)
        rectfill(buffer, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN, makecol(0, 0, 0));
        drawing_mode(DRAW_MODE_TRANS, NULL, 0, 0);
        set_trans_blender(0, 0, 0, 128); // Transparence à 50%
        rectfill(buffer, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN, makecol(0, 0, 0));
        drawing_mode(DRAW_MODE_SOLID, NULL, 0, 0);

        //définir la taille et position du menu
        int menu_largeur = 400;
        int menu_hauteur = 300;
        int menu_x = (LARGEUR_ECRAN - menu_largeur) / 2;
        int menu_y = (HAUTEUR_ECRAN - menu_hauteur) / 2;

        for (int i = 0; i < menu_hauteur; i++) {
            int gris = 20 + (i * 10 / menu_hauteur); // Dégradé de 20 à 30
            hline(buffer, menu_x, menu_y + i, menu_x + menu_largeur, makecol(gris, gris, gris + 5));
        }

        //bordure du menu
        rect(buffer, menu_x, menu_y, menu_x + menu_largeur, menu_y + menu_hauteur, makecol(80, 80, 90));
        rect(buffer, menu_x + 1, menu_y + 1, menu_x + menu_largeur - 1, menu_y + menu_hauteur - 1, makecol(50, 50, 60));

        //titre du menu
        textout_centre_ex(buffer, font, "PAUSE",
                        LARGEUR_ECRAN / 2, menu_y + 30,
                        makecol(220, 220, 255), -1);

        //message de confirmation
        textout_centre_ex(buffer, font, "Quitter la partie ?",
                        LARGEUR_ECRAN / 2, menu_y + 100,
                        makecol(255, 255, 255), -1);

        //boutons
        int btn_largeur = 120;
        int btn_hauteur = 40;
        int marge_boutons = 20;

        //bouton continuer
        int btn_continuer_x = menu_x + (menu_largeur / 2) - btn_largeur - (marge_boutons / 2);
        int btn_continuer_y = menu_y + 160;

        int couleur_continuer = (choix == 0) ? makecol(60, 100, 60) : makecol(40, 70, 40);
        rectfill(buffer, btn_continuer_x, btn_continuer_y,
                btn_continuer_x + btn_largeur, btn_continuer_y + btn_hauteur,
                couleur_continuer);
        rect(buffer, btn_continuer_x, btn_continuer_y,
            btn_continuer_x + btn_largeur, btn_continuer_y + btn_hauteur,
            makecol(100, 140, 100));
        textout_centre_ex(buffer, font, "Continuer",
                        btn_continuer_x + btn_largeur/2, btn_continuer_y + btn_hauteur/2 - 4,
                        makecol(230, 230, 230), -1);

        //bouton quitter
        int btn_quitter_x = menu_x + (menu_largeur / 2) + (marge_boutons / 2);
        int btn_quitter_y = menu_y + 160;

        int couleur_quitter = (choix == 1) ? makecol(100, 60, 60) : makecol(70, 40, 40);
        rectfill(buffer, btn_quitter_x, btn_quitter_y,
                btn_quitter_x + btn_largeur, btn_quitter_y + btn_hauteur,
                couleur_quitter);
        rect(buffer, btn_quitter_x, btn_quitter_y,
            btn_quitter_x + btn_largeur, btn_quitter_y + btn_hauteur,
            makecol(140, 100, 100));
        textout_centre_ex(buffer, font, "Quitter",
                        btn_quitter_x + btn_largeur/2, btn_quitter_y + btn_hauteur/2 - 4,
                        makecol(230, 230, 230), -1);

        textout_centre_ex(buffer, font, "Utilisez les fleches et Entree, ou cliquez",
                        LARGEUR_ECRAN / 2, menu_y + menu_hauteur - 40,
                        makecol(180, 180, 200), -1);

        //navigation clavier
       if (keypressed()) {
           int touche = readkey();
           int scancode = touche >> 8;

           if (scancode == KEY_LEFT || scancode == KEY_RIGHT) {
               choix = 1 - choix; // Basculer entre 0 et 1
           }
           else if (scancode == KEY_ENTER || scancode == KEY_SPACE) {
               sortie = 1;
           }
           else if (scancode == KEY_ESC) {
               choix = 0; //par défaut, on continue si Échap est pressé à nouveau
               sortie = 1;
           }
       }

       //navigation souris
       if (mouse_b & 1) {
           if (mouse_x >= btn_continuer_x && mouse_x <= btn_continuer_x + btn_largeur &&
               mouse_y >= btn_continuer_y && mouse_y <= btn_continuer_y + btn_hauteur) {
               choix = 0;
               sortie = 1;
           }
           else if (mouse_x >= btn_quitter_x && mouse_x <= btn_quitter_x + btn_largeur &&
                   mouse_y >= btn_quitter_y && mouse_y <= btn_quitter_y + btn_hauteur) {
               choix = 1;
               sortie = 1;
           }

           //attendre que le bouton de la souris soit relâché
           while (mouse_b & 1) {
               rest(10);
           }
       }

       blit(buffer, screen, 0, 0, 0, 0, LARGEUR_ECRAN, HAUTEUR_ECRAN);

       rest(10);
   }

   destroy_bitmap(capture);
   clear_keybuf();

   return choix;
}
