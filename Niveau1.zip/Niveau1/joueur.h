#ifndef JOUEUR_H
#define JOUEUR_H
#include "niveau1.h"

void saisir_pseudo(char *pseudo);
int charger_joueurs(Joueur *joueurs);
void sauvegarder_joueurs(Joueur *joueurs, int nb_joueurs);
int trouver_joueur(Joueur *joueurs, int nb_joueurs, char *pseudo);
void ajouter_joueur(Joueur *joueurs, int *nb_joueurs, char *pseudo);


#endif //JOUEUR_H